function show()
{
    alert("you clciked me : ")
}