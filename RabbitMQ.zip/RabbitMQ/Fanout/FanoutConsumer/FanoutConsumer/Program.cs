﻿using System;
using System.Collections.Generic;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace FanoutConsumer
{
    class Program
    {
        //Command
        static void Main(string[] args)
        {
            Console.WriteLine("Queue Name : " + args[0]);
            var factory = new ConnectionFactory() { HostName = "localhost" };
            var connection = factory.CreateConnection();
            var channel = connection.CreateModel();

            channel.ExchangeDeclare(exchange: "fanout-exch",
                type: ExchangeType.Fanout,
                durable: false,
                autoDelete: false,
                arguments: null
                );

            var arguments = new Dictionary<string, object>()
            {
                {"x-message-ttl",60000 },//TTL for queue message(all messages)
                {"x-expires", 30*60*1000 } //Queue expiry after idle timeout, in milliseconds
            };

            channel.QueueDeclare(args[0], durable: false, exclusive: false, autoDelete: false, arguments:arguments);
            channel.QueueBind(args[0], "fanout-exch", "", null);
            
            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (ch, ea) =>
              {
                  var message = Encoding.UTF8.GetString(ea.Body);
                  Console.WriteLine("Waiting for message...ENTER to exit");
                  Console.WriteLine($"Message received : {message}");
                  channel.BasicAck(ea.DeliveryTag, multiple: false);//explicit acknowledgement
                  //Console.ReadLine();
              };
            channel.BasicConsume(queue: args[0], autoAck: false, consumer: consumer); //disable auto ack
            channel.Dispose();
            connection.Dispose();
        }
    }
}
